//
//  UIImageView+Extension.swift
//  VishrutProject
//
//  Created by Vishrut Dungrani on 26/05/25.
//

import Foundation
import Kingfisher
import UIKit

extension UIImageView {
  func loadFromUrlString(_ urlString:String?, placeholder:Placeholder? = nil, needAccess:Bool = true, completionHandler: ((Result<RetrieveImageResult, KingfisherError>) -> Void)? = nil) {
    if (urlString == nil) {
      return
    }
   
    let urStr = urlString?.replacingOccurrences(of: "|", with: "%7c")
    guard let urString = urStr else {return}
    let url = URL(string: urString)
    self.kf.indicatorType = .activity
    self.kf.setImage(with: url, placeholder: placeholder, completionHandler: completionHandler)
  }
  func bottomCornerRedius(redius: CGFloat){
    self.layer.cornerRadius = redius
    self.layer.maskedCorners = [ .layerMinXMaxYCorner, .layerMaxXMaxYCorner]
  }
}

extension Data {
    func convertToJsonObject() -> [String: Any]? {
        let theJSONText = String(data: self, encoding: .utf8)
        let newString = theJSONText!.replacingOccurrences(of: ";",
                                                          with: ",",
                                                          options: .literal,
                                                          range: nil)
        return newString.convertToDictionary()
    }
    
}

extension String {
    func convertToDictionary() -> [String: Any]? {
        if let data = self.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
            }
        }
        return nil
    }
}
