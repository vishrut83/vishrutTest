//
//  HomeViewModelResponse.swift
//  VishrutProject
//
//  Created by Vishrut Dungrani on 26/05/25.
//

import Foundation

struct HomeViewModelResponse : Codable {
    let status : String?
    let data : [HomeDataResponse]?
    let totalCount : Int?
    let currentPage : Int?
    let message : String?

    enum CodingKeys: String, CodingKey {

        case status = "status"
        case data = "data"
        case totalCount = "totalCount"
        case currentPage = "currentPage"
        case message = "message"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        status = try values.decodeIfPresent(String.self, forKey: .status)
        data = try values.decodeIfPresent([HomeDataResponse].self, forKey: .data)
        totalCount = try values.decodeIfPresent(Int.self, forKey: .totalCount)
        currentPage = try values.decodeIfPresent(Int.self, forKey: .currentPage)
        message = try values.decodeIfPresent(String.self, forKey: .message)
    }

}

struct HomeDataResponse : Codable {
    let post : HomePostResponse?

    enum CodingKeys: String, CodingKey {

        case post = "post"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        post = try values.decodeIfPresent(HomePostResponse.self, forKey: .post)
    }

}

struct HomePostResponse : Codable {
    let location : HomeLocationResponse?
    let _id : String?
    let userId : HomeUserResponse?
    let repostPostId : RepostPostId?
    let description : String?
    let settingRepost : Bool?
    let media : [HomeMediaResponse]?
    let privacy : String?
    let group : [HomeGroupResponse]?
    let circleId : String?
    let postType : String?
    let hideLikeCount : Bool?
    let turnOffComment : Bool?
    let isPin : Bool?
    let canReply : Bool?
    let canShareCirclePost : Bool?
    let countRepost : Int?
    let hashTag : [String]?
    let postVisibleUserIds : [String]?
    let postVisibleGroupId : [String]?
    let allowDownloadPost : Bool?
    let createAt : String?
    let likeUser : [HomeLikeUserResponse]?
    let totalLike : Int?
    let selfLike : Bool?
    let shareCount : Int?
    let comments : Int?
    let savePost : Bool?

    enum CodingKeys: String, CodingKey {

        case location = "location"
        case _id = "_id"
        case userId = "userId"
        case repostPostId = "RepostPostId"
        case description = "description"
        case settingRepost = "settingRepost"
        case media = "media"
        case privacy = "privacy"
        case group = "group"
        case circleId = "circleId"
        case postType = "postType"
        case hideLikeCount = "hideLikeCount"
        case turnOffComment = "turnOffComment"
        case isPin = "isPin"
        case canReply = "canReply"
        case canShareCirclePost = "canShareCirclePost"
        case countRepost = "countRepost"
        case hashTag = "hashTag"
        case postVisibleUserIds = "postVisibleUserIds"
        case postVisibleGroupId = "postVisibleGroupId"
        case allowDownloadPost = "allowDownloadPost"
        case createAt = "createAt"
        case likeUser = "likeUser"
        case totalLike = "TotalLike"
        case selfLike = "selfLike"
        case shareCount = "shareCount"
        case comments = "comments"
        case savePost = "savePost"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        location = try values.decodeIfPresent(HomeLocationResponse.self, forKey: .location)
        _id = try values.decodeIfPresent(String.self, forKey: ._id)
        userId = try values.decodeIfPresent(HomeUserResponse.self, forKey: .userId)
        repostPostId = try values.decodeIfPresent(RepostPostId.self, forKey: .repostPostId)
        description = try values.decodeIfPresent(String.self, forKey: .description)
        settingRepost = try values.decodeIfPresent(Bool.self, forKey: .settingRepost)
        media = try values.decodeIfPresent([HomeMediaResponse].self, forKey: .media)
        privacy = try values.decodeIfPresent(String.self, forKey: .privacy)
        group = try values.decodeIfPresent([HomeGroupResponse].self, forKey: .group)
        circleId = try values.decodeIfPresent(String.self, forKey: .circleId)
        postType = try values.decodeIfPresent(String.self, forKey: .postType)
        hideLikeCount = try values.decodeIfPresent(Bool.self, forKey: .hideLikeCount)
        turnOffComment = try values.decodeIfPresent(Bool.self, forKey: .turnOffComment)
        isPin = try values.decodeIfPresent(Bool.self, forKey: .isPin)
        canReply = try values.decodeIfPresent(Bool.self, forKey: .canReply)
        canShareCirclePost = try values.decodeIfPresent(Bool.self, forKey: .canShareCirclePost)
        countRepost = try values.decodeIfPresent(Int.self, forKey: .countRepost)
        hashTag = try values.decodeIfPresent([String].self, forKey: .hashTag)
        postVisibleUserIds = try values.decodeIfPresent([String].self, forKey: .postVisibleUserIds)
        postVisibleGroupId = try values.decodeIfPresent([String].self, forKey: .postVisibleGroupId)
        allowDownloadPost = try values.decodeIfPresent(Bool.self, forKey: .allowDownloadPost)
        createAt = try values.decodeIfPresent(String.self, forKey: .createAt)
        likeUser = try values.decodeIfPresent([HomeLikeUserResponse].self, forKey: .likeUser)
        totalLike = try values.decodeIfPresent(Int.self, forKey: .totalLike)
        selfLike = try values.decodeIfPresent(Bool.self, forKey: .selfLike)
        shareCount = try values.decodeIfPresent(Int.self, forKey: .shareCount)
        comments = try values.decodeIfPresent(Int.self, forKey: .comments)
        savePost = try values.decodeIfPresent(Bool.self, forKey: .savePost)
    }
    

}

struct HomeUserResponse : Codable {
    let _id : String?
    let name : String?
    let email : String?
    let phone : Int?
    let profile : String?
    let userType : String?
    let contactStatus : Bool?
    let webName : String?

    enum CodingKeys: String, CodingKey {

        case _id = "_id"
        case name = "name"
        case email = "email"
        case phone = "phone"
        case profile = "profile"
        case userType = "userType"
        case contactStatus = "contactStatus"
        case webName = "webName"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        _id = try values.decodeIfPresent(String.self, forKey: ._id)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        email = try values.decodeIfPresent(String.self, forKey: .email)
        phone = try values.decodeIfPresent(Int.self, forKey: .phone)
        profile = try values.decodeIfPresent(String.self, forKey: .profile)
        userType = try values.decodeIfPresent(String.self, forKey: .userType)
        contactStatus = try values.decodeIfPresent(Bool.self, forKey: .contactStatus)
        webName = try values.decodeIfPresent(String.self, forKey: .webName)
    }

}

struct HomeMediaResponse : Codable {
    let url : String?
    let aspectRatio : Double?
    let type : String?
    let thumbnail : String?
    let duration : String?
    let size : Int?
    let mediaTagUser : [String]?
    let _id : String?

    enum CodingKeys: String, CodingKey {

        case url = "url"
        case aspectRatio = "aspectRatio"
        case type = "type"
        case thumbnail = "thumbnail"
        case duration = "duration"
        case size = "size"
        case mediaTagUser = "mediaTagUser"
        case _id = "_id"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        url = try values.decodeIfPresent(String.self, forKey: .url)
        aspectRatio = try values.decodeIfPresent(Double.self, forKey: .aspectRatio)
        type = try values.decodeIfPresent(String.self, forKey: .type)
        thumbnail = try values.decodeIfPresent(String.self, forKey: .thumbnail)
        duration = try values.decodeIfPresent(String.self, forKey: .duration)
        size = try values.decodeIfPresent(Int.self, forKey: .size)
        mediaTagUser = try values.decodeIfPresent([String].self, forKey: .mediaTagUser)
        _id = try values.decodeIfPresent(String.self, forKey: ._id)
    }

}

struct HomeLocationResponse : Codable {
    let name : String?
    var longitude : Double = 0.0
    var latitude : Double = 0.0

    enum CodingKeys: String, CodingKey {

        case name = "name"
        case longitude = "longitude"
        case latitude = "latitude"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        longitude = try values.decodeIfPresent(Double.self, forKey: .longitude) ?? 0.0 
        latitude = try values.decodeIfPresent(Double.self, forKey: .latitude) ?? 0.0
    }

}

struct HomeGroupResponse : Codable {
    let groupId : HomeGroupIdResponse?

    enum CodingKeys: String, CodingKey {

        case groupId = "GroupId"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        groupId = try values.decodeIfPresent(HomeGroupIdResponse.self, forKey: .groupId)
    }

}

struct HomeGroupIdResponse : Codable {
    let _id : String?
    let groupName : String?
    let groupProfile : String?
    let groupType : String?
    let isDeleted : Bool?
    let storyCount : Int?
    let isSeenStory : Bool?
    let isJoined : Bool?
    let userRole : String?

    enum CodingKeys: String, CodingKey {

        case _id = "_id"
        case groupName = "groupName"
        case groupProfile = "groupProfile"
        case groupType = "groupType"
        case isDeleted = "isDeleted"
        case storyCount = "storyCount"
        case isSeenStory = "isSeenStory"
        case isJoined = "isJoined"
        case userRole = "userRole"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        _id = try values.decodeIfPresent(String.self, forKey: ._id)
        groupName = try values.decodeIfPresent(String.self, forKey: .groupName)
        groupProfile = try values.decodeIfPresent(String.self, forKey: .groupProfile)
        groupType = try values.decodeIfPresent(String.self, forKey: .groupType)
        isDeleted = try values.decodeIfPresent(Bool.self, forKey: .isDeleted)
        storyCount = try values.decodeIfPresent(Int.self, forKey: .storyCount)
        isSeenStory = try values.decodeIfPresent(Bool.self, forKey: .isSeenStory)
        isJoined = try values.decodeIfPresent(Bool.self, forKey: .isJoined)
        userRole = try values.decodeIfPresent(String.self, forKey: .userRole)
    }

}

struct HomeLikeUserResponse : Codable {
    let userId : HomeUserResponse?

    enum CodingKeys: String, CodingKey {

        case userId = "userId"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        userId = try values.decodeIfPresent(HomeUserResponse.self, forKey: .userId)
    }

}


struct RepostPostId : Codable {
    let _id : String?
    let userId : UserId?
    let circleData : CircleData?

    enum CodingKeys: String, CodingKey {

        case _id = "_id"
        case userId = "userId"
        case circleData = "circleData"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        _id = try values.decodeIfPresent(String.self, forKey: ._id)
        userId = try values.decodeIfPresent(UserId.self, forKey: .userId)
        circleData = try values.decodeIfPresent(CircleData.self, forKey: .circleData)
    }

}


struct CircleData : Codable {
    let _id : String?
    let groupName : String?
    let groupProfile : String?
    let groupType : String?
    let isDeleted : Bool?

    enum CodingKeys: String, CodingKey {

        case _id = "_id"
        case groupName = "groupName"
        case groupProfile = "groupProfile"
        case groupType = "groupType"
        case isDeleted = "isDeleted"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        _id = try values.decodeIfPresent(String.self, forKey: ._id)
        groupName = try values.decodeIfPresent(String.self, forKey: .groupName)
        groupProfile = try values.decodeIfPresent(String.self, forKey: .groupProfile)
        groupType = try values.decodeIfPresent(String.self, forKey: .groupType)
        isDeleted = try values.decodeIfPresent(Bool.self, forKey: .isDeleted)
    }

}

struct UserId : Codable {
    let _id : String?
    let name : String?
    let email : String?
    let phone : Int?
    let profile : String?
    let userType : String?

    enum CodingKeys: String, CodingKey {

        case _id = "_id"
        case name = "name"
        case email = "email"
        case phone = "phone"
        case profile = "profile"
        case userType = "userType"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        _id = try values.decodeIfPresent(String.self, forKey: ._id)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        email = try values.decodeIfPresent(String.self, forKey: .email)
        phone = try values.decodeIfPresent(Int.self, forKey: .phone)
        profile = try values.decodeIfPresent(String.self, forKey: .profile)
        userType = try values.decodeIfPresent(String.self, forKey: .userType)
    }

}
