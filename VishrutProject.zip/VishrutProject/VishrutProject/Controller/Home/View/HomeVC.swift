//
//  HomeVC.swift
//  VishrutTest
//
//  Created by Vishrut Dungrani on 26/05/25.
//

import UIKit
import AVKit

class HomeVC: UIViewController {
    
    // MARK: - @IBOutlet
    @IBOutlet weak var tblView: UITableView! {
        didSet {
            let nibHome = UINib(nibName: "HomeListCell", bundle: nil)
            tblView.register(nibHome, forCellReuseIdentifier: "HomeListCell")
            
            tblView.dataSource = self
            tblView.delegate = self
            /*tblView.estimatedRowHeight = 300
            tblView.rowHeight = UITableView.automaticDimension*/
            
        }
    }
    
    // MARK: - viewModel
    var viewModel = HomeVM()
    
    // MARK: - view Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.viewModel.fetchPosts { success, message in
            self.tblView.reloadData()
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        let height = scrollView.frame.size.height
        
        if offsetY > contentHeight - height - 100 {
            if !viewModel.isLoading && viewModel.currentPage < viewModel.totalPages {
                viewModel.currentPage += 1
                self.viewModel.fetchPosts { success, message in
                    self.tblView.reloadData()
                }
            }
        }
    }
}

// MARK: - tblView Delegate & Datasource
extension HomeVC : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tblView.dequeueReusableCell(withIdentifier: "HomeListCell") as! HomeListCell
        
        let dicData = viewModel.posts[indexPath.row]
        
        cell.lblName.text = dicData.post?.userId?.name
        
        if let dateStr = dicData.post?.createAt {
            let inputFormatter = DateFormatter()
            inputFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
            
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = "yyyy-MM-dd"
            
            if let date = inputFormatter.date(from: dateStr) {
                cell.lblDate.text = outputFormatter.string(from: date)
            } else {
                cell.lblDate.text = dateStr
            }
        }
        
        cell.lblLIkeCount.text = "\(dicData.post?.totalLike ?? 0)"
        cell.lblShareCount.text = "\(dicData.post?.shareCount ?? 0)"
        cell.lblMassageCount.text = "\(dicData.post?.comments ?? 0)"
        cell.lblTital.text = dicData.post?.description
        
        cell.btnLike.tag = indexPath.row
        
        cell.arrMedia.removeAll()
        if let arrMedia = dicData.post?.media {
            for obj in arrMedia {
                cell.arrMedia.append(obj)
            }
            cell.collectionView.reloadData()
        }
        
        cell.tapOnLikeAtion = {
            cell.isLiked.toggle()
            
            // Update UI colors
            cell.imgLike.tintColor = cell.isLiked ? .blue : .black
            cell.lblLIkeCount.textColor = cell.isLiked ? .blue : .black

            // Update like count
            if var likeCount = Int(cell.lblLIkeCount.text ?? "0") {
                if cell.isLiked {
                    likeCount += 1
                } else {
                    likeCount = max(0, likeCount - 1) 
                }
                cell.lblLIkeCount.text = "\(likeCount)"
            }
        }
        
        cell.imgProfile.loadFromUrlString("https://d3b13iucq1ptzy.cloudfront.net/" + (dicData.post?.userId?.profile ?? ""),placeholder: UIImage(named: "ic_Profile"))
        
        cell.imgComment.loadFromUrlString("https://d3b13iucq1ptzy.cloudfront.net/" + (dicData.post?.userId?.profile ?? ""),placeholder: UIImage(named: "ic_Profile"))
        
        cell.img1.isHidden = true
        cell.img2.isHidden = true
        cell.img3.isHidden = true
        cell.imgWeight1.constant = 0
        cell.imgWeight2.constant = 0
        cell.imgWeight3.constant = 0
        if let likeUsers = dicData.post?.likeUser {
            let baseUrl = "https://d3b13iucq1ptzy.cloudfront.net/"
            
            if likeUsers.count > 0 {
                cell.img1.isHidden = false
                cell.img1.loadFromUrlString(baseUrl + (likeUsers[0].userId?.profile ?? ""),placeholder: UIImage(named: "ic_Profile"))
                cell.lblLikeText.text = "\(dicData.post?.likeUser?[0].userId?.name ?? "") and \(dicData.post?.totalLike ?? 0) others tapped this"
                cell.imgWeight1.constant = 20
                cell.imgWeight2.constant = 0
                cell.imgWeight3.constant = 0
            }
            if likeUsers.count > 1 {
                cell.img2.isHidden = false
                cell.img2.loadFromUrlString(baseUrl + (likeUsers[1].userId?.profile ?? ""),placeholder: UIImage(named: "ic_Profile"))
                cell.imgWeight1.constant = 20
                cell.imgWeight3.constant = 0
                cell.imgWeight2.constant = 20
            }
            if likeUsers.count > 2 {
                cell.img3.isHidden = false
                cell.img3.loadFromUrlString(baseUrl + (likeUsers[2].userId?.profile ?? ""),placeholder: UIImage(named: "ic_Profile"))
                cell.imgWeight1.constant = 20
                cell.imgWeight2.constant = 20
                cell.imgWeight3.constant = 20
            }
        }
        
        return cell
    }
    
}
