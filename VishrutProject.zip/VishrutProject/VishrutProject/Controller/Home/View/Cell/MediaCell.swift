//
//  MediaCell.swift
//  VishrutTest
//
//  Created by Vishrut Dungrani on 26/05/25.


import UIKit
import AVFoundation

class MediaCell: UICollectionViewCell {

    // MARK: - @IBOutlet
   // @IBOutlet weak var videoVIew: UIView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var viewImg: UIView!
 
    // MARK: - variabel
    private var playerLayer: AVPlayerLayer?

    // MARK: - view Cycle
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
