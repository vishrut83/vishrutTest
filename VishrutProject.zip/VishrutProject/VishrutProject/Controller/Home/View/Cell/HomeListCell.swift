//
//  HomeListCell.swift
//  Folk Events
//
//  Created by Vishrut Dungrani on 08/07/24.
//

import UIKit
import Lightbox
import AVFoundation

class HomeListCell: UITableViewCell {

    // MARK: - @IBOutlet
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var lblTital: UILabel!
    
    @IBOutlet weak var btnComment: UIButton!
    @IBOutlet weak var btnShare: UIButton!
    @IBOutlet weak var btnMenu: UIButton!
    @IBOutlet weak var imgLike: UIImageView!
    @IBOutlet weak var lblLIkeCount: UILabel!
    @IBOutlet weak var lblMassageCount: UILabel!
    @IBOutlet weak var lblShareCount: UILabel!
    
    @IBOutlet weak var viewImage: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var btnLike: UIButton!
    
    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img3: UIImageView!
    @IBOutlet weak var lblLikeText: UILabel!
    @IBOutlet weak var imgWeight2: NSLayoutConstraint!
    @IBOutlet weak var imgWeight3: NSLayoutConstraint!
    @IBOutlet weak var imgWeight1: NSLayoutConstraint!
    
    @IBOutlet weak var imgComment: UIImageView!
    @IBOutlet weak var txtComment: UITextField!
    
    // MARK: - variable
    var arrMedia: [HomeMediaResponse] = [HomeMediaResponse]()
    
    var isLiked: Bool = false
    var tapOnLikeAtion: (()->Void)?
    
    // MARK: - view Cycle
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code

        collectionView.dataSource = self
        collectionView.delegate = self
        
        let nibView = UINib(nibName: "MediaCell", bundle: nil)
        collectionView.register(nibView, forCellWithReuseIdentifier: "MediaCell")
        
        img1.layer.cornerRadius = 10
        img2.layer.cornerRadius = 10
        img3.layer.cornerRadius = 10
        imgComment.layer.cornerRadius = 10
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
       
    }
    
    // MARK: - Action Method
    @IBAction func tapOnLikeAction(_ sender: UIButton) {
        tapOnLikeAtion?()
    }
    @IBAction func tapOnCommentAction(_ sender: Any) {
        
    }
    @IBAction func tapOnShareAction(_ sender: Any) {
        
    }
    @IBAction func tapOnMenuAction(_ sender: Any) {
        
    }

}

// MARK: - collectionView Delegate & DataSource
extension HomeListCell: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrMedia.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MediaCell", for: indexPath) as! MediaCell

        let item = arrMedia[indexPath.item]
        cell.imageView.loadFromUrlString("https://d3b13iucq1ptzy.cloudfront.net/uploads/posts/image/" + (item.url ?? ""),placeholder: UIImage(named: "ic_placeholder"))
            
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView.bounds.size
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
}
