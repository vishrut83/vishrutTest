//
//  HomeVM.swift
//  VishrutProject
//
//  Created by Vishrut Dungrani on 26/05/25.
//

import Foundation
import UIKit

class HomeVM {
    
    var posts: [HomeDataResponse] = []
    var successResponse: (()->Void)?
    
    var currentPage = 1
    let totalPages = 10
    var isLoading = false
    var activityIndicator: UIActivityIndicatorView?
    
    func fetchPosts(completion: @escaping (_ success: Bool, _ message: String?) -> Void) {
        guard !isLoading, currentPage <= totalPages,
              let url = URL(string: "http://43.205.16.96:3000/api/v2/post/getPost?page=\(currentPage)") else {
            print("Invalid URL or pagination limit reached")
            return
        }
        
        DispatchQueue.main.async {
            self.activityIndicator?.startAnimating()
        }
        
        isLoading = true
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyRGF0YSI6eyJfaWQiOiI1NzMiLCJuYW1lIjoiaGFyc2hpbCIsImNvdW50cnlDb2RlIjoiKzkxIiwiZW1haWwiOiIiLCJwaG9uZSI6OTMxMzU5Nzc5MCwiZGVzY3JpcHRpb24iOiJoZWxsbyIsInRhZ3MiOiIiLCJwcm9maWxlIjoidXBsb2Fkcy9wcm9maWxlLzFiMzFlYTJkLWMzY2UtNGMxYS04OTI4LTAwMDVkNzZhMzNiMCIsIm90cFNlbmRDb3VudCI6MSwibGFzdE90cFNlbmREYXRlIjoiMjAyNS0wMS0wN1QxMToyNTozNi40NjBaIiwiaXNVc2VyVmVyaWZpZWQiOnRydWUsImlzQmFubmVkIjpmYWxzZSwiZGF0ZU9mQmlydGgiOiIxOTkzLTAxLTAxVDAwOjAwOjAwLjAwMFoiLCJsaW5rIjoiIiwiaXNEZWxldGVkIjpmYWxzZSwib2xkUGhvbmUiOm51bGwsInVzZXJUeXBlIjoiVXNlciIsImNyZWF0ZUF0IjoiMjAyNC0wOS0zMFQwNzoyMDoyNC45OTNaIiwidXBkYXRlQXQiOiIyMDI1LTA1LTIxVDA1OjQ3OjA3LjAxNFoiLCJiaW9VcGRhdGUiOiIyMDI1LTA1LTEyVDA1OjMxOjU4LjcyMVoiLCJfX3YiOjAsImlzT3RwVmVyaWZpZWQiOnRydWV9LCJpYXQiOjE3NDc4OTc1MjR9.ElEaPgKGowIvY2m_kqqPG6ON5WR_5XHuc5EK43ldjLQ",
                         forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                self.activityIndicator?.stopAnimating()
                self.isLoading = false
                if let error = error {
                    print("Network error: \(error.localizedDescription)")
                    completion(false, nil)
                    return
                }
                
                guard let data = data else {
                    print("No data received")
                    completion(false, nil)
                    return
                }
                
                if let response = data.convertToJsonObject() {
                    print(response)
                    if let data = response["data"] as? NSArray {
                        
                        if let arrPost = self.parsePostList(data) {
                            for obj in arrPost {
                                if let arrMedia = obj.post?.media {
                                    let hasVideo = arrMedia.contains { $0.type == "Image" }
                                    if hasVideo == true {
                                        self.posts.append(obj)
                                    }
                                }
                            }
                            
                            self.currentPage += 1
                            completion(true, nil)
                        }
                        self.successResponse?()
                    }
                }
            }
        }
        task.resume()
    }
    
    func parsePostList(_ params: Any) -> [HomeDataResponse]? {
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: params, options: [])
            if let jsonString = String(data: jsonData, encoding: .utf8) {
                print("JSON to decode:", jsonString)
            }

            let song = try JSONDecoder().decode([HomeDataResponse].self, from: jsonData)
            return song
        } catch {
            print("Decoding error:", error)
            return nil
        }
    }
    
}
